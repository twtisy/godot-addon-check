@tool
extends EditorPlugin
# Example only; never executed by this tool.
func example():
    OS.execute("example_program", [])
